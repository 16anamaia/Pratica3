package questao1;

class Ingresso {
    private double valor;

    public Ingresso(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}

class Normal extends Ingresso {
    public Normal(double valor) {
        super(valor);
    }

    public void imprimeValor() {
        System.out.println("Ingresso Normal");
        System.out.println("Valor do Ingresso: R$" + getValor());
    }
}

class VIP extends Ingresso {
    private double valorAdicional;

    public VIP(double valor, double valorAdicional) {
        super(valor);
        this.valorAdicional = valorAdicional;
    }

    public void imprimeValor() {
        double valorTotal = getValor() + valorAdicional;
        System.out.println("Ingresso VIP");
        System.out.println("Valor do Ingresso VIP: R$" + valorTotal);
    }
}

public class Main {
    public static void main(String[] args) {
        // Exemplo de uso das classes
        double valorNormal = 50.0;
        double valorAdicionalVIP = 20.0;

        Normal ingressoNormal = new Normal(valorNormal);
        VIP ingressoVIP = new VIP(valorNormal, valorAdicionalVIP);

        ingressoNormal.imprimeValor();
        ingressoVIP.imprimeValor();
    }
}

